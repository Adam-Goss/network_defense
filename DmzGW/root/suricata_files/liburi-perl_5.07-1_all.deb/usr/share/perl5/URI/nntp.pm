package URI::nntp;  # draft-gilman-news-url-01

use strict;
use warnings;

our $VERSION = '5.07';

use parent 'URI::news';

1;
